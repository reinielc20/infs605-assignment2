from flask import Flask, request, jsonify
import os

app = Flask(__name__)

students = []

@app.route("/students", methods=["GET"])
def get_students():
    return jsonify(students)

@app.route("/students", methods=["POST"])
def add_student():
    data = request.get_json()
    students.append(data)
    return jsonify({"message": "Student added"}), 201

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)